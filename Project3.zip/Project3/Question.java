public class Question {
    private String description; // Questions -> it can be blank or multiple choice;
    private String answer; //Correct answers

    public String getDescription() {
        return description;
    }

    public String [] option(){
        return option();
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }


}