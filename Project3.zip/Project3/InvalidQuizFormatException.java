import java.io.FileNotFoundException;

public class InvalidQuizFormatException extends FileNotFoundException {

    public InvalidQuizFormatException(){}
}
